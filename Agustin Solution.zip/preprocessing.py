from typing import *

import pandas as pd
from pandas.tseries.holiday import USFederalHolidayCalendar

# Geo Data
import geopandas as gpd
from shapely.geometry import shape


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalizes the column names in the input DataFrame to a consistent format.

    Args:
        df (pd.DataFrame): The input DataFrame with column names to be normalized.

    Returns:
        pd.DataFrame: The DataFrame with renamed columns for consistency.
    """

    return df.rename(
        columns={
            "VendorID": "vendor_id",
            "RatecodeID": "ratecode_id",
            "PULocationID": "pu_location_id",
            "DOLocationID": "do_location_id",
        }
    )


def valid_vendor_payment_filter(df: pd.DataFrame) -> pd.DataFrame:
    """
    Filters the input DataFrame to remove rows where vendor_id equals 6,
    payment_type equals 0, or the pickup and dropoff times are the same.

    Args:
        df (pd.DataFrame): The input DataFrame containing the data to filter.

    Returns:
        pd.DataFrame: The filtered DataFrame.
    """
    return df.query(
        "vendor_id != 6 and payment_type != 0 and tpep_pickup_datetime != tpep_dropoff_datetime"
    )


def quantile_filter(
    df: pd.DataFrame, cols: list[str], low: float, high: float
) -> pd.DataFrame:
    """
    Filters the input DataFrame by applying quantile-based thresholds to specified columns.

    Args:
        df (pd.DataFrame): The input DataFrame to filter.
        cols (list[str]): A list of column names to apply the quantile filtering.
        low (float): The lower quantile threshold (e.g., 0.05 for the 5th percentile).
        high (float): The upper quantile threshold (e.g., 0.95 for the 95th percentile).

    Returns:
        pd.DataFrame: The filtered DataFrame with rows within the specified quantile range for each column.
    """

    for col in cols:
        percentiles = df[col].quantile([low, high]).values
        df = df.query(f"({col} >= {percentiles[0]} and {col} <= {percentiles[1]})")
    return df


def col_to_datetime(df: pd.DataFrame) -> pd.DataFrame:
    """
    Converts the 'tpep_pickup_datetime' and 'tpep_dropoff_datetime' columns
    in the input DataFrame to datetime objects.

    Args:
        df (pd.DataFrame): The input DataFrame containing the datetime columns.

    Returns:
        pd.DataFrame: The DataFrame with the specified columns converted to datetime format.
    """

    return df.assign(
        tpep_pickup_datetime=pd.to_datetime(df["tpep_pickup_datetime"]),
        tpep_dropoff_datetime=pd.to_datetime(df["tpep_dropoff_datetime"]),
    )


def get_us_holidays(year: int) -> pd.DatetimeIndex:
    """
    Retrieves the US federal holidays for a specified year.

    Args:
        year (int): The year for which to retrieve the US federal holidays.

    Returns:
        pd.DatetimeIndex: A DatetimeIndex object containing the dates of the US federal holidays.
    """

    us_hollydays = USFederalHolidayCalendar().holidays(
        start=f"{year}-01-01", end=f"{year}-12-31"
    )
    us_hollydays = pd.to_datetime(us_hollydays).date
    return us_hollydays


def valid_trip_filter(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    """
    Filters the input DataFrame by removing rows where any of the specified columns have non-positive values.

    Args:
        df (pd.DataFrame): The input DataFrame containing trip data.
        cols (list[str]): A list of column names that should contain positive values.

    Returns:
        pd.DataFrame: The filtered DataFrame where all specified columns have values greater than 0.
    """

    validation_trip_query = " and ".join([f"{col} > 0" for col in cols])
    return df.query(validation_trip_query)


def impute_missing(df: pd.DataFrame) -> pd.DataFrame:
    """
    Imputes missing values in the input DataFrame by filling specific columns with default values or the mean.

    - 'passenger_count' is filled with the mean value (converted to an integer).
    - 'ratecode_id', 'congestion_surcharge', and 'airport_fee' are filled with 0.

    Args:
        df (pd.DataFrame): The input DataFrame with missing values.

    Returns:
        pd.DataFrame: The DataFrame with missing values imputed.
    """

    return df.assign(
        passenger_count=df["passenger_count"].fillna(
            value=int(df["passenger_count"].mean())
        ),
        ratecode_id=df["ratecode_id"].fillna(value=0),
        congestion_surcharge=df["congestion_surcharge"].fillna(value=0),
        airport_fee=df["airport_fee"].fillna(value=0),
    )


def preprocess_geo_data(geo_df: pd.DataFrame) -> pd.DataFrame:
    """
    Preprocesses geographic data by sorting based on area, removing duplicates, calculating area in square miles,
    and adding centroid information.

    Args:
        geo_df (pd.DataFrame): The input DataFrame containing geographic data with 'LocationID' and 'geometry' columns.

    Returns:
        pd.DataFrame: The processed DataFrame with calculated area in square miles and centroid information.
    """

    geo_df["area_mi2"] = geo_df.geometry.apply(lambda x: shape(x).area / 2.788e7)

    geo_df = geo_df.sort_values("area_mi2", ascending=False).drop_duplicates(
        "LocationID", keep="first"
    )

    geo_df["centroid"] = geo_df.centroid

    return geo_df


def get_geo_maps(geo_df: pd.DataFrame) -> tuple[dict[int, str], dict[int, float]]:
    """
    Creates mappings for boroughs and areas from geographic data based on 'LocationID'.

    Args:
        geo_df (pd.DataFrame): The input DataFrame containing geographic data with 'LocationID', 'borough', and 'area_mi2' columns.

    Returns:
        tuple[dict[int, str], dict[int, float]]:
            - A dictionary mapping 'LocationID' to borough names.
            - A dictionary mapping 'LocationID' to the area in square miles, with a fixed value for location 264.
    """
    borough_map = geo_df.set_index("LocationID")["borough"].to_dict()
    area_map = geo_df.set_index("LocationID")["area_mi2"].to_dict()
    area_map[264] = 0  # Fix missing value
    return borough_map, area_map
