from typing import *
import pandas as pd
import numpy as np


def calculate_time_features(
    df: pd.DataFrame, us_holidays: pd.DatetimeIndex
) -> pd.DataFrame:
    """
    Calculates various time-based features for each trip in the input DataFrame, including:

    - 'tpep_pickup_date': The pickup date.
    - 'tpep_pickup_month': The month of pickup.
    - 'tpep_pickup_hour': The hour of pickup.
    - 'tpep_dropoff_hour': The hour of dropoff.
    - 'tpep_pickup_day': The day of the pickup.
    - 'tpep_pickup_weekday': The day of the week for pickup.
    - 'tpep_dropoff_weekday': The day of the week for dropoff.
    - 'trip_duration_s': Trip duration in seconds.
    - 'trip_duration_m': Trip duration in minutes.
    - 'trip_duration_h': Trip duration in hours.
    - 'holiday': Whether the pickup date falls on a US federal holiday.

    Args:
        df (pd.DataFrame): The input DataFrame containing trip data.
        us_holidays (pd.DatetimeIndex): A DatetimeIndex object containing the dates of US federal holidays.

    Returns:
        pd.DataFrame: The DataFrame with the newly calculated time features.
    """

    return df.assign(
        tpep_pickup_date=lambda x: x["tpep_pickup_datetime"].dt.date,
        tpep_pickup_month=df["tpep_pickup_datetime"].dt.month,
        tpep_pickup_hour=df["tpep_pickup_datetime"].dt.hour,
        tpep_dropoff_hour=df["tpep_dropoff_datetime"].dt.hour,
        tpep_pickup_day=df["tpep_pickup_datetime"].dt.day,
        tpep_pickup_weekday=df["tpep_pickup_datetime"].dt.weekday,
        tpep_dropoff_weekday=df["tpep_dropoff_datetime"].dt.weekday,
        trip_duration_s=(
            df["tpep_dropoff_datetime"] - df["tpep_pickup_datetime"]
        ).dt.total_seconds(),
        trip_duration_m=(
            df["tpep_dropoff_datetime"] - df["tpep_pickup_datetime"]
        ).dt.total_seconds()
        / 60,
        trip_duration_h=(
            df["tpep_dropoff_datetime"] - df["tpep_pickup_datetime"]
        ).dt.total_seconds()
        / 3600,
        holiday=lambda x: x["tpep_pickup_date"].isin(us_holidays),
    )


def calculate_trip_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculates various trip features for the input DataFrame, including:

    - 'trip_distance_mi': The distance of the trip in miles.
    - 'trip_distance_km': The distance of the trip in kilometers.
    - 'speed_mph': The average speed of the trip in miles per hour.
    - 'speed_kmh': The average speed of the trip in kilometers per hour.
    - 'tips_per_min': The average tip amount per minute of the trip.

    The function replaces infinite values with NaN.

    Args:
        df (pd.DataFrame): The input DataFrame containing trip data.

    Returns:
        pd.DataFrame: The DataFrame with the newly calculated trip features.
    """
    return df.assign(
        trip_distance_mi=lambda x: x["trip_distance"],
        trip_distance_km=lambda x: x["trip_distance"] * 1.609,
        speed_mph=lambda x: x["trip_distance_mi"] / x["trip_duration_h"],
        speed_kmh=lambda x: x["trip_distance_km"] / x["trip_duration_h"],
        tips_per_min=lambda x: x["tip_amount"] / x["trip_duration_m"],
    ).replace([np.inf, -np.inf], np.nan)


def estimate_distance(x: list[int], distances: dict, geo_df) -> float:
    """
    Estimates the distance between two location points using geographical data.
    Caches the calculated distances for reuse.

    Args:
        x (list[int]): A list containing two location IDs for which the distance will be estimated.
        distances (dict): A dictionary used to store and reuse previously calculated distances.
        geo_df: GeoDataFrame containing geographical information for location IDs.

    Returns:
        float: The estimated distance between the two locations, or 0 if one of the locations is unknown.
    """

    key = "->".join([str(i) for i in x])

    point1 = x[0]
    point2 = x[1]

    if key in distances.keys():
        return distances[key]

    known_points = geo_df.LocationID.values

    if point1 not in known_points or point2 not in known_points:
        distances[key] = 0
        return 0
    else:
        df = (
            geo_df.query(f"LocationID == {point1}")
            .distance(geo_df.query(f"LocationID == {point2}"), align=False)
            .reset_index()
            .rename(columns={0: "estimated_distance"})
        )
        distances[key] = df.estimated_distance.values[0]
        return distances[key]


def add_estimated_distance(df: pd.DataFrame, geo_df) -> pd.DataFrame:
    """
    Adds an estimated distance column to the DataFrame based on pickup and drop-off location IDs.

    Args:
        df (pd.DataFrame): The input DataFrame containing 'pu_location_id' and 'do_location_id' columns.
        geo_df: GeoDataFrame containing geographical information for location IDs.

    Returns:
        pd.DataFrame: The input DataFrame with an additional 'estimated_distance' column,
                      which contains the estimated distances between pickup and drop-off locations.
    """
    distances = {}

    df["from_to"] = df[["pu_location_id", "do_location_id"]].apply(list, axis=1)
    df["from_to"] = df["from_to"].apply(lambda x: sorted(x))
    df["estimated_distance"] = df["from_to"].apply(
        lambda x: estimate_distance(x, distances, geo_df)
    )
    df.drop(columns=["from_to"], inplace=True)

    return df


def add_borough(df: pd.DataFrame, borough_map: dict[int, str]) -> pd.DataFrame:
    """
    Adds borough information to the DataFrame based on pickup and drop-off location IDs,
    indicating if the trip occurred within the same borough and creating dummy variables for boroughs.

    Args:
        df (pd.DataFrame): The input DataFrame containing 'pu_location_id' and 'do_location_id' columns.
        borough_map (dict[int, str]): A mapping of location IDs to borough names.

    Returns:
        pd.DataFrame: The input DataFrame with new columns for 'pu_borough', 'do_borough', 'same_borough',
                      and one-hot encoded boroughs for both pickup and drop-off locations.
    """
    df["pu_borough"] = df["pu_location_id"].apply(
        lambda x: borough_map[x] if x in borough_map.keys() else "Unknown"
    )

    df["do_borough"] = df["do_location_id"].apply(
        lambda x: borough_map[x] if x in borough_map.keys() else "Unknown"
    )

    df["same_borough"] = df["pu_borough"] == df["do_borough"]

    df = pd.get_dummies(df, columns=["pu_borough", "do_borough"])

    return df
